﻿using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Runpath.API.BLL;
using Runpath.Common;

namespace Runpath.API.Controllers
{
    [Route("api/[controller]")]
    public class GalleryController : ControllerBase
    {
        private GalleryManager manager;

		public GalleryController()
		{
			this.manager = new GalleryManager();
		}

        /// <summary>
        /// Gets an album and its child photos based on userID
        /// </summary>
        /// <param name="id">id (int)</param>
        [HttpGet]
        [Route("GetAlbums")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        public async Task<ActionResult<Album>> GetAlbums(int? id)
        {
            return Ok(await manager.GetAlbumsByUserID(id));
        }
    }
}
