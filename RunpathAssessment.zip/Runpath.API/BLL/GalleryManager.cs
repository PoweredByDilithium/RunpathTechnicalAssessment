using System.Collections.Generic;
using Runpath.Common;
using System.Threading.Tasks;
using System.Linq;

namespace Runpath.API.BLL
{
	public class GalleryManager : IGalleryManager
	{
        
		private Client client;

		public GalleryManager()
		{
			this.client = new Client(Global.PlaceholderURL);
		}

		private async Task<List<Album>> IntegratePhotos(List<Album> albums)
		{
			List<Album> photoAlbums = new List<Album>();
			foreach(var album in albums.ToList())
			{
				album.Photos = await GetPhotos(album.ID);
				photoAlbums.Add(album);
			}
			return photoAlbums;
		}

		public async Task<List<Album>> GetAlbumsByUserID(int? userID)
		{
			List<Album> albums = await GetAlbums();
			List<Album> userAlbums =  albums.Where(x => userID == null || x.UserID == userID)
						 					.ToList();
			return await IntegratePhotos(userAlbums);
		}

		
		public async Task<List<Album>> GetAlbums()
		{
			return await client.GetAlbums();
		}

		public async Task<List<Photo>> GetPhotos(int? albumID)
		{
			return await client.GetPhotos(albumID);
		}
	}
}