using System.Collections.Generic;
using System.Threading.Tasks;
using Runpath.Common;

namespace Runpath.API.BLL
{
	public interface IGalleryManager
	{
		Task<List<Album>> GetAlbums();

		Task<List<Photo>> GetPhotos(int? albumID);

		Task<List<Album>> GetAlbumsByUserID(int? userID);
	}
}