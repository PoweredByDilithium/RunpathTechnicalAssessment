namespace Runpath.API.BLL
{
	public class Global
	{
		public static string PlaceholderURL = "http://jsonplaceholder.typicode.com/";
	}
}