# Runpath

Launch the Runpath.API project in VS Code

Swagger will open on port 5001

Call `/api/Gallery/GetAlbums` with optional `id` parameter for User ID

Response will be returned in JSON format
