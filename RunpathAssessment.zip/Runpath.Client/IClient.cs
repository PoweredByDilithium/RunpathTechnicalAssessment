using System.Collections.Generic;
using System.Threading.Tasks;
using Runpath.Common;

namespace Runpath
{
	public interface IClient
	{

		Task<List<Album>> GetAlbums();

		Task<List<Photo>> GetPhotos(int? albumID);

	}
}
