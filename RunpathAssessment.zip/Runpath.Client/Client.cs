﻿using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Runpath.Common;

namespace Runpath
{
	public class Client : IClient
	{
		private static readonly HttpClient client = new HttpClient();
		private string uri = "";

		public Client(string uri)
		{
			this.uri = "http://jsonplaceholder.typicode.com";
		}

		public async Task<List<Album>> GetAlbums()
		{
			try
			{
				var res = await client.GetAsync($"{uri}/albums");
				string ret = await res.Content.ReadAsStringAsync();
				return JsonConvert.DeserializeObject<List<Album>>(ret);
			}
			catch { }
			return null;
		}

		public async Task<List<Photo>> GetPhotos(int? albumID)
		{
			try
			{
				var res = albumID == null ? 
						  await client.GetAsync($"{uri}/photos") : 
						  await client.GetAsync($"{uri}/photos?albumId={albumID}");
				string ret = await res.Content.ReadAsStringAsync();
				return JsonConvert.DeserializeObject<List<Photo>>(ret);
			}
			catch { }
			return null;
		}
	}
}
