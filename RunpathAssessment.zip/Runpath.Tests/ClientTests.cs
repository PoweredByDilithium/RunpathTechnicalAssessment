using System.Collections.Generic;
using NUnit.Framework;
using Runpath;
using Runpath.Common;

namespace Tests
{
    [TestFixture]
    public class ClientTests
    {
        private Client client;
        
        [SetUp]
        public void Setup()
        {
            client = new Client(Global.PlaceholderURL);
        }

        [Test]
        public async System.Threading.Tasks.Task GetAlbums_WhenCalled_ReturnAlbumsAsync()
        {
			List<Album> albums = await client.GetAlbums();
			Assert.That(albums.Count, Is.GreaterThan(0));
        }

        [Test]
        public async System.Threading.Tasks.Task GetPhotos_WhenCalled_ReturnPhotosAsync()
        {
			List<Photo> photos = await client.GetPhotos(null);
			Assert.That(photos.Count, Is.GreaterThan(0));
        }
    }
}