using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using NUnit.Framework;
using Runpath.API.BLL;
using Runpath.Common;

namespace Tests
{
    [TestFixture]
    public class GalleryTests
    {
        private GalleryManager manager;
        
        [SetUp]
        public void Setup()
        {
            manager = new GalleryManager();
        }

        [Test]
        [TestCase(1)]
        public async Task GetAlbums_WhenCalled_ReturnAllAlbumsForUser(int userID)
        {
           List<Album> albumsForUser = await manager.GetAlbumsByUserID(userID);
           bool sameUser = albumsForUser.All(x => x.UserID == userID);
           Assert.That(sameUser, Is.True);
           Task.WaitAll();
        }

        [Test]
        [TestCase(1)]
        [TestCase(2)]
        public async Task GetAlbums_WhenCalled_ReturnPhotosForAlbum(int? albumID)
        {
           List<Photo> photos = await manager.GetPhotos(albumID);
           bool sameAlbum = photos.All(x => x.AlbumID == albumID);
           Assert.That(sameAlbum, Is.True);
           Task.WaitAll();
        }

        [Test]
        [TestCase(null)]
        public async Task GetAlbums_WhenCalled_ReturnAllPhotos(int? albumID)
        {
           List<Photo> photos = await manager.GetPhotos(albumID);
           bool sameAlbum = photos.FirstOrDefault().AlbumID != photos.LastOrDefault().AlbumID;
           Assert.That(sameAlbum, Is.True);
           Task.WaitAll();
        }
    }
}