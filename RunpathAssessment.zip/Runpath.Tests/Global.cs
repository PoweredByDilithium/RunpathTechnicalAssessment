	public class Global
	{
		public static string PlaceholderURL = "http://jsonplaceholder.typicode.com/";
	}