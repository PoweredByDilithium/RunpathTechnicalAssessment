

namespace Runpath.Common
{
	public partial class Photo
	{
		public int PhototID { get; set; }
		public int AlbumID { get; set; }
		public string Title { get; set; }
		public string URL { get; set; }
		public string ThumbnailURL { get; set; }
	}
}